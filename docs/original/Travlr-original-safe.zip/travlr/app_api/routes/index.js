const express = require("express");
const router = express.Router();
const authenticateJWT = require("../middleware/auth");

const tripsController = require("../controllers/trips");
const authController = require("../controllers/authentication");


router.post("/register", authController.register);
router.post("/login", authController.login);

const jwt = require('jsonwebtoken'); // Enable JSON Web Tokens
router.route("/trips")
    .get(tripsController.tripsList) 
    .post(authenticateJWT, tripsController.tripsAddTrip);

router.route("/trips/:tripCode")
    .get(tripsController.tripsFindByCode)
    .put(authenticateJWT,tripsController.tripsUpdateTrip);

    // define route for login endpoint
router
.route('/login')
.post(authController.login);

module.exports = router;
