var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');

var indexRouter = require('./app_server/routes/index');
var usersRouter = require('./app_server/routes/users');
var travelRouter = require('./app_server/routes/travel');
var apiRouter = require('./app_api/routes/index');
// Wire in our authentication module
var passport = require('passport');
require('./app_api/config/passport');
var handlebars = require('hbs');

require('./app_api/models/db');

var app = express();
// Catch unauthorized error and create 401
app.use((err, req, res, next) => {
if(err.name === 'UnauthorizedError') {
res
.status(401)
.json({"message": err.name + ": " + err.message});
}
});
// view engine setup
app.set('views', path.join(__dirname, 'app_server', 'views'));

handlebars.registerPartials(__dirname + '/app_server/views/partials');
handlebars.registerHelper('eq', function(a,b){
  return a === b;
})
app.set('view engine', 'hbs');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(passport.initialize());
//Enable CORS
app.use('/api', (req, res, next) =>{
  res.header('Access-Control-Allow-Origin', 'http://localhost:4200');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
  next();
})

app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use('/travel', travelRouter);
app.use('/api', apiRouter);
// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});
require('dotenv').config();
// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
